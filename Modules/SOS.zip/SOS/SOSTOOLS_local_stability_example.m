pvar x y
mu=1; r=2.8;
g=r-(x^2+y^2);
f=[-y;
    -mu*(1-x^2)*y+x];
prog=sosprogram([x y]);
Z4=monomials([x y],0:4);
Z2=monomials([x y],0:2);
[prog,V]=sossosvar(prog,Z2);
%[prog,t]=sospolyvar(prog,Z4);
%prog=sosineq(prog,V+t*g-.01);
V=V+.0001*(x^4+y^4);
prog=soseq(prog,subs(V,[x; y],[0; 0]))
nablaV=[diff(V,x);diff(V,y)];
[prog,s]=sossosvar(prog,Z2);
prog=sosineq(prog,-nablaV'*f-s*g);
prog=sossolve(prog);
Vn=sosgetsol(prog,V)

% max gamma show g>0 for all v<gamma
gamma=6.6
prog=sosprogram([x y]);
Z4=monomials([x y],0:4);
Z2=monomials([x y],0:2);
[prog,s]=sossosvar(prog,Z2);
Vg=gamma-Vn;
prog=sosineq(prog,g-s*Vg);
prog=sossolve(prog);
