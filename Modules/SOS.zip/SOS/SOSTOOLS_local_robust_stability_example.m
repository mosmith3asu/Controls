
% Rayleigh System Non-robust
pvar x1 x2
zeta=1.5; alpha=1;
r=1; g=r-(x1^2+x2^2);
f=[-2*zeta*(1-alpha*x1^2)*x1+x2;   -x1];
vartable=[x1 x2];
prog=sosprogram(vartable);
Z2=monomials(vartable,0:2);
Z3=monomials(vartable,0:3);
[prog,V]=sossosvar(prog,Z3);
[prog,r]=sossosvar(prog,Z2);
%prog=sosineq(prog,V+t*g-.01);
V=V+.0001*(x1^2+x2^2)+r*g;
prog=soseq(prog,subs(V,[x1; x2],[0; 0]))
nablaV=[diff(V,x1);diff(V,x2)];
[prog,s]=sossosvar(prog,Z3);
prog=sosineq(prog,-nablaV'*f-s*g);
prog=sossolve(prog);
Vn=sosgetsol(prog,V);

% Rayleigh System Robust
pvar x1 x2 z a
zmin=1.4;zmax=1.6;amin=.8;amax=1.2;
r=.8; g1=r-(x1^2+x2^2);
g2=(amax-a)*(a-amin);g3=(zmax-z)*(z-zmin);
f=[-2*z*(1-a*x1^2)*x1+x2; -x1];
vartable=[x1 x2 a z];
prog=sosprogram(vartable);
Z1=monomials(vartable,0:1);
Z2=monomials(vartable,0:2);
Z3=monomials(vartable,0:3);
[prog,V0]=sossosvar(prog,Z2);
[prog,r1]=sossosvar(prog,Z1);
[prog,r2]=sossosvar(prog,Z1);
[prog,r3]=sossosvar(prog,Z1);
V=V0+.001*(x1^2+x2^2)+g1*r1+g2*r2+g3*r3;
prog=soseq(prog,subs(V,[x1, x2]',[0, 0]'));
nablaV=[diff(V,x1);diff(V,x2)];
[prog,s1]=sossosvar(prog,Z2);
[prog,s2]=sossosvar(prog,Z2);
[prog,s3]=sossosvar(prog,Z2);
prog=sosineq(prog,-nablaV'*f-s1*g1-s2*g2-s3*g3);
prog=sossolve(prog);
Vn=sosgetsol(prog,V)


