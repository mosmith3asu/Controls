pvar m c k
Am=[0 m;-c*m -k];
mmin=.1;mmax=1;cmin=.1;cmax=1;kmin=.1;kmax=1;
g1=(mmax-m)*(m-mmin);
g2=(cmax-c)*(c-cmin);
g3=(kmax-k)*(k-kmin);
vartable=[m c k]
prog=sosprogram(vartable);
[prog,S0]=sosposmatrvar(prog,2,4,vartable);
[prog,S1]=sosposmatrvar(prog,2,4,vartable);
[prog,S2]=sosposmatrvar(prog,2,4,vartable);
[prog,S3]=sosposmatrvar(prog,2,4,vartable);
P=S0+g1*S1+g2*S2+g3*S3+.00001*eye(2);
[prog,R0]=sosposmatrvar(prog,2,4,vartable);
[prog,R1]=sosposmatrvar(prog,2,4,vartable);
[prog,R2]=sosposmatrvar(prog,2,4,vartable);
[prog,R3]=sosposmatrvar(prog,2,4,vartable);
Derv=Am'*P+P*Am;
constr=-Derv-m*(R0+R1*g1+R2*g2+R3*g3);
prog=sosmateq_hack(prog,constr);
prog=sossolve(prog);
Pn=sosgetsol(prog,P)