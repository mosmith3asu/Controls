clear all
sdpvar x y
f=[-y-1.5*x^2-.5*x^3;
    3*x-y];
[V,Vc]=polynomial([x y],4);
F=[Vc(1)==0];
F=[F;sos(V-.00001*(x^2+y^2))];
nablaV=jacobian(V,[x y]);
F=[F;sos(-nablaV*f)];
solvesos(F,[],[],[Vc])


