pvar y z
M=[(y^2+1)*z^2 y*z;
    y*z y^4+y^2-2*y+1];
prog=sosprogram([y z]);
prog=sosmatrixineq(prog,M);
prog=sossolve(prog);


pvar y z
M=[(y^2+1)*z^2 y*z;
    y*z y^4+y^2-2*y+1];
prog=sosprogram([y z]);
[prog,P]=sospolymatrixvar(prog,monomials([y z],0:4),[2 2]);
MEQ=reshape(M-P,4,1);
prog=soseq(prog,MEQ);
prog=sosmatrixineq(prog,P);
prog=sossolve(prog);
