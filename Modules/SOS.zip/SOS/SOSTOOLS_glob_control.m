
pvar x1 x2 x3
u=0;
g=1-x1^2+x2^2+x3^2;
f=[-x1+x2-x3;
    -x1*x3-x2+u;
    -x1+u];
prog=sosprogram([x1 x2 x3]);
Z4=monomials([x1 x2 x3],0:4);
Z2=monomials([x1 x2 x3],0:2);
[prog,V]=sossosvar(prog,Z2);
[prog,t]=sospolyvar(prog,Z4);
prog=sosineq(prog,V+t*g-.01);
%V=V+.0001*(x1^4+x2^4+x3^4);
%prog=soseq(prog,subs(V,[x; y],[0; 0]))
nablaV=[diff(V,x1);diff(V,x2);diff(V,x3)];
prog=sosineq(prog,-nablaV'*f);
prog=sossolve(prog);
Vn=sosgetsol(prog,V)



pvar x1 x2 x3
u=0;
g=1-x1^2+x2^2+x3^2;
f=[-x1+x2-x3;
    -x1*x3-x2+u;
    -x1+u];
prog=sosprogram([x1 x2 x3]);
Z=monomials([x1 x2 x3],1:2);
[prog,V]=sossosvar(prog,Z);
V=V+.0001*(x1^4+x2^4+x3^4);
%prog=soseq(prog,subs(V,[x; y],[0; 0]))
nablaV=[diff(V,x1);diff(V,x2);diff(V,x3)];
prog=sosineq(prog,-nablaV'*f+s*(1-x1));
prog=sossolve(prog);
Vn=sosgetsol(prog,V)


% Global Controller Synthesis on $||<1$ with v=x^2+y^2+z^2
pvar x1 x2 x3
prog=sosprogram([x1 x2 x3]);
Z4=monomials([x1 x2 x3],1:1);
Z2=monomials([x1 x2 x3],0:3);
[prog,k1]=sospolyvar(prog,Z4);
[prog,k2]=sospolyvar(prog,Z4);
u1=k1; u2=k2;
f=[-x1+x2-x3;
    -x1*x3-x2+u1;
    -x1+u2];
V=x1^2+x2^2+x3^2;
nablaV=[diff(V,x1);diff(V,x2);diff(V,x3)];
prog=sosineq(prog,-(nablaV'*f));
prog=sossolve(prog);
k1n=sosgetsol(prog,k1)
k2n=sosgetsol(prog,k2)



% Local Controller Synthesis on $||<1$ with v=x^2+y^2+z^2
pvar x1 x2 x3
prog=sosprogram([x1 x2 x3]);
r=1; g=r-(x1^2+x2^2+x3^2);
Z4=monomials([x1 x2 x3],0:3);
Z2=monomials([x1 x2 x3],0:3);
[prog,k1]=sospolyvar(prog,Z4);
[prog,k2]=sospolyvar(prog,Z4);
u1=k1; u2=k2;
f=[-x1+x2-x3;
    -x1*x3-x2+u1;
    -x1+u2];
V=x1^2+x2^2+x3^2;
%V=x1^4+x2^4+x3^4;
%V=Vn;
nablaV=[diff(V,x1);diff(V,x2);diff(V,x3)];
[prog,s]=sossosvar(prog,Z2);
%prog=sosineq(prog,-(nablaV'*f)-s*g);
prog=sosineq(prog,-(nablaV'*f));
prog=sossolve(prog);
k1n=sosgetsol(prog,k1)
k2n=sosgetsol(prog,k2)


u1=k1n;
u2=k2n;
f=[-x1+x2-x3;
    -x1*x3-x2+u1;
    -x1+u2];
prog=sosprogram([x1 x2 x3]);
Z=monomials([x1 x2 x3],1:2);
[prog,V]=sossosvar(prog,Z);
V=V+.0001*(x1^4+x2^4+x3^4);
%prog=soseq(prog,subs(V,[x; y],[0; 0]))
nablaV=[diff(V,x1);diff(V,x2);diff(V,x3)];
prog=sosineq(prog,-nablaV'*f-2*V);
prog=sossolve(prog);
Vn=sosgetsol(prog,V)

u1=k1n;
u2=k2n;
f=[-x1+x2-x3;
    -x1*x3-x2+u1;
    -x1+u2];
prog=sosprogram([x1 x2 x3]);
Z4=monomials([x1 x2 x3],0:4);
Z2=monomials([x1 x2 x3],0:2);
[prog,V]=sossosvar(prog,Z2);
[prog,t]=sospolyvar(prog,Z4);
prog=sosineq(prog,V+t*g-.01);
%prog=soseq(prog,subs(V,[x; y],[0; 0]))
nablaV=[diff(V,x1);diff(V,x2);diff(V,x3)];
prog=sosineq(prog,-nablaV'*f-2*V);
prog=sossolve(prog);
Vn=sosgetsol(prog,V)




prog=sosprogram([x1 x2 x3]);
r=.01;
g=r-(x1^2+x2^2+x3^2);
Z4=monomials([x1 x2 x3],0:4);
Z2=monomials([x1 x2 x3],0:2);
[prog,k1]=sospolyvar(prog,Z4);
%[prog,k2]=sospolyvar(prog,Z4);
u1=k1;
u2=k1;
f=[-x1+x2-x3;
    -x1*x3-x2+u1;
    -x1+u2];
%V=x1^2+x2^2+x3^2;
%V=x1^4+x2^4+x3^4;
V=Vn;
nablaV=[diff(V,x1);diff(V,x2);diff(V,x3)];
[prog,s]=sossosvar(prog,Z2);
prog=sosineq(prog,-(nablaV'*f)-s*g);
%prog=sosineq(prog,-(nablaV'*f));
prog=sossolve(prog);
k1n=sosgetsol(prog,k1)





