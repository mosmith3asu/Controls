pvar w1 w2 w3
J1=2;J2=1;J3=1; 
k1=1;k2=1;k3=1;
u1=-k1*w1;u2=-k2*w2;u3=-k3*w3;
f=[(J2-J3)/J1*w2*w3+u1;
    (J3-J1)/J2*w3*w1+u2;
    (J1-J2)/J3*w1*w2+u3];
prog=sosprogram([w1 w2 w3]);
Z=monomials([w1 w2 w3],1:2);
[prog,V]=sossosvar(prog,Z);
V=V+.0001*(w1^4+w2^4+w3^4);
%prog=soseq(prog,subs(V,[x; y],[0; 0]))
nablaV=[diff(V,w1);diff(V,w2);diff(V,w3)];
prog=sosineq(prog,-nablaV'*f-4.0*V);
prog=sossolve(prog);
Vn=sosgetsol(prog,V)