pvar x y
f=[-y-1.5*x^2-.5*x^3;
    3*x-y];
prog=sosprogram([x y]);
Z=monomials([x,y],1:2);
[prog,V]=sossosvar(prog,Z);
V=V+.0001*(x^4+y^4);
prog=soseq(prog,subs(V,[x; y],[0; 0]))
nablaV=[diff(V,x);diff(V,y)];
prog=sosineq(prog,-nablaV'*f);
prog=sossolve(prog);
Vn=sosgetsol(prog,V)